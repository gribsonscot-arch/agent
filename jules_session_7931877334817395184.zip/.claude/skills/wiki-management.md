# Skill: Wiki Management
Description: Instructions for maintaining the personal knowledge base.

- On every new source, extract key entities and create/update pages.
- Ensure cross-links exist between related topics.
- Maintain a clear and up-to-date index.md.
- Log every major change in log.md.
