document.addEventListener('DOMContentLoaded', () => {
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');
    const chatHistory = document.getElementById('chat-history');
    const displayUserId = document.getElementById('display-user-id');
    const profileContent = document.getElementById('profile-content');
    const wikiIndex = document.getElementById('wiki-index');

    // Simple user ID management for demo purposes
    let userId = localStorage.getItem('claudual_user_id') || 'user_' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('claudual_user_id', userId);
    if (displayUserId) displayUserId.textContent = userId;

    const appendMessage = (text, role) => {
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${role}`;
        msgDiv.innerHTML = `<p>${text}</p>`;
        chatHistory.appendChild(msgDiv);
        chatHistory.scrollTop = chatHistory.scrollHeight;
    };

    const sendMessage = async () => {
        const text = userInput.value.trim();
        if (!text) return;

        appendMessage(text, 'user');
        userInput.value = '';

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: text, user_id: userId, source: 'web' })
            });
            const data = await response.json();
            if (data.response) {
                appendMessage(data.response, 'bot');
            } else {
                appendMessage('Error: No response from agent.', 'system');
            }
        } catch (error) {
            console.error('Fetch error:', error);
            appendMessage('Error: Could not connect to the server.', 'system');
        }
    };

    if (sendBtn) {
        sendBtn.addEventListener('click', sendMessage);
        userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendMessage();
        });
    }

    // Dashboard Logic
    if (profileContent) {
        // Mock data for demo if backend is not fully setup with Supabase
        profileContent.innerHTML = `
            <h3>Summary</h3>
            <p>A proactive user interested in knowledge management and AI automation.</p>
            <h3>Preferences</h3>
            <ul>
                <li>Tone: Professional yet friendly</li>
                <li>Channel: Web preferred for long-form discussion</li>
            </ul>
        `;
    }

    if (wikiIndex) {
        wikiIndex.innerHTML = `
            <ul>
                <li>[[Project Claudual]]: The architecture of this personal agent.</li>
                <li>[[Knowledge Management]]: The core philosophy behind the Wiki.</li>
                <li>[[Tool Handlers]]: Technical specs for shell and file I/O.</li>
            </ul>
        `;
    }
});
