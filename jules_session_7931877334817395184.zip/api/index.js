const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs').promises;
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const { createClient } = require('@supabase/supabase-js');
const Groq = require('groq-sdk');
const axios = require('axios');
require('dotenv').config();

const app = express();

// Supabase Setup
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = (supabaseUrl && supabaseKey) ? createClient(supabaseUrl, supabaseKey) : null;

async function saveConversation(user_id, message, response, source) {
  if (!supabase) return;
  const { error } = await supabase
    .from('conversations')
    .insert([{ user_id, message, response, source }]);
  if (error) console.error('Error saving conversation:', error);
}

async function getUserProfile(user_id) {
  if (!supabase) return { preferences: {}, summary: 'I am still learning about you.', personality_notes: '' };
  const { data, error } = await supabase
    .from('user_profiles')
    .select('*')
    .eq('user_id', user_id)
    .single();
  
  if (error && error.code !== 'PGRST116') { // PGRST116 is "no rows returned"
    console.error('Error fetching user profile:', error);
  }
  return data || { user_id, preferences: {}, summary: 'New user.', personality_notes: '' };
}

async function updateUserProfile(user_id, updates) {
  if (!supabase) return;
  const { error } = await supabase
    .from('user_profiles')
    .upsert({ user_id, ...updates, last_seen: new Date() });
  if (error) console.error('Error updating user profile:', error);
}

// Wiki Maintenance Logic
const WIKI_DIR = path.join(__dirname, '../wiki');
const RAW_DIR = path.join(__dirname, '../raw');

async function updateWikiIndex(pageName, summary) {
  const indexPath = path.join(WIKI_DIR, 'index.md');
  const entry = `- [[${pageName}]]: ${summary}\n`;
  try {
    await fs.appendFile(indexPath, entry);
  } catch (error) {
    console.error('Error updating wiki index:', error);
  }
}

async function logWikiActivity(activity) {
  const logPath = path.join(WIKI_DIR, 'log.md');
  const timestamp = new Date().toISOString().split('T')[0];
  const entry = `## [${timestamp}] ${activity}\n`;
  try {
    await fs.appendFile(logPath, entry);
  } catch (error) {
    console.error('Error logging wiki activity:', error);
  }
}

async function ingestSource(filename, content) {
  const rawPath = path.join(RAW_DIR, filename);
  await fs.writeFile(rawPath, content);
  
  // Logic for LLM to process source would go here
  // For now, we just log the ingestion
  await logWikiActivity(`ingest | ${filename}`);
}

// Tool Handlers
async function executeShellCommand(command) {
  try {
    const { stdout, stderr } = await execPromise(command);
    return stdout || stderr;
  } catch (error) {
    return `Error: ${error.message}`;
  }
}

async function readFile(filepath) {
  try {
    return await fs.readFile(filepath, 'utf8');
  } catch (error) {
    return `Error reading file: ${error.message}`;
  }
}

async function writeFile(filepath, content) {
  try {
    await fs.writeFile(filepath, content);
    return 'File written successfully';
  } catch (error) {
    return `Error writing file: ${error.message}`;
  }
}

// Groq Setup
const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

async function getAIResponse(message, userProfile, source) {
  const isMessaging = source === 'whatsapp' || source === 'telegram';
  const systemPrompt = `You are Claudual, a deeply personal AI agent. You remember everything about the user. 
User Summary: ${userProfile.summary}
User Preferences: ${JSON.stringify(userProfile.preferences)}
${userProfile.personality_notes ? `Notes: ${userProfile.personality_notes}` : ''}

You are ${isMessaging ? 'extremely concise (under 200 characters)' : 'fully conversational'}. 
You proactively help — anticipating needs, following up on past topics, and surfacing relevant context without being asked.

You can also perform tasks like reading/writing files and running shell commands. If the user asks for such a task, indicate what you are doing.`;

  try {
    const chatCompletion = await groq.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ],
      model: 'llama-3.3-70b-versatile',
      max_tokens: isMessaging ? 100 : 1000,
    });

    return chatCompletion.choices[0].message.content;
  } catch (error) {
    console.error('Groq API Error:', error);
    return "I'm sorry, I'm having trouble thinking right now.";
  }
}

const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(morgan('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Routes
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'ok', message: 'Claudual API is running' });
});

// Chat endpoint
app.post('/api/chat', async (req, res) => {
  const { message, user_id, source = 'web' } = req.body;
  if (!message || !user_id) {
    return res.status(400).json({ error: 'Missing message or user_id' });
  }
  
  const userProfile = await getUserProfile(user_id);
  const response = await getAIResponse(message, userProfile, source);
  
  await saveConversation(user_id, message, response, source);
  
  res.status(200).json({ 
    response,
    user_id,
    source
  });
});

// WhatsApp Webhook (Twilio)
app.post('/api/whatsapp', async (req, res) => {
  const { Body, From } = req.body;
  const user_id = From; // Use phone number as user_id
  
  const userProfile = await getUserProfile(user_id);
  const response = await getAIResponse(Body, userProfile, 'whatsapp');
  
  await saveConversation(user_id, Body, response, 'whatsapp');

  res.set('Content-Type', 'text/xml');
  res.send(`<Response><Message>${response}</Message></Response>`);
});

// Telegram Webhook
app.post('/api/telegram', async (req, res) => {
  const { message } = req.body;
  if (message) {
    const chatId = message.chat.id;
    const text = message.text;
    const user_id = `telegram_${chatId}`;

    const userProfile = await getUserProfile(user_id);
    const response = await getAIResponse(text, userProfile, 'telegram');
    
    await saveConversation(user_id, text, response, 'telegram');

    // Send response back via Telegram Bot API
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (botToken) {
      try {
        await axios.post(`https://api.telegram.org/bot${botToken}/sendMessage`, {
          chat_id: chatId,
          text: response
        });
      } catch (error) {
        console.error('Telegram Bot API Error:', error.response ? error.response.data : error.message);
      }
    }
  }
  res.status(200).send('OK');
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Start server (only if not running as a Vercel function)
if (process.env.NODE_ENV !== 'production') {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

module.exports = app;
